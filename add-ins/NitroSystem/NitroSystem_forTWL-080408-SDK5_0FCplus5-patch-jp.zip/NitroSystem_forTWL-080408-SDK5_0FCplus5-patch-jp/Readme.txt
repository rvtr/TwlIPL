■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
■　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　  　　　■
■　NITRO-System for TWL 080408 ( TWL-SDK5.0 FC plus5 対応版 )　　　  　　　■
■　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　■
■　Jul. 1, 2008  　　　　　　　　　　  　　　　　　　　　　　　　　　　　　■
■　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　■
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■


このパッチは、NITRO-System for TWL 2008/04/08版をTWL-SDK5.0 FC plus5に
対応させるためのものです。NITRO-System for TWLのライブラリをTWL-SDK5.0 FC plus5
を用いてビルドしたものに差し替えます。

このパッチをインストールするためには、同梱されているファイルをNITRO-System
 for TWL 2008/04/08版がインストールされているディレクトリに上書きコ
ピーしてください。

詳しくは、NitroSystemディレクトリの
Readme-NitroSystem_forTWL-080408-SDK5_0FCplus5-patch-jp.txt をご覧下さい。

